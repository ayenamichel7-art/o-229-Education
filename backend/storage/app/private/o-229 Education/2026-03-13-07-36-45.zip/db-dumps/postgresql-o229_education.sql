--
-- PostgreSQL database dump
--

\restrict gZCmezhhFJ4sXScheSoMLETqnSDqkjwlIsd17P0TBvNQ22vaetqAXwLmdP0u8TO

-- Dumped from database version 16.13
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: academic_years; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.academic_years (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    starts_at date NOT NULL,
    ends_at date NOT NULL,
    is_current boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.academic_years OWNER TO postgres;

--
-- Name: academic_years_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.academic_years_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.academic_years_id_seq OWNER TO postgres;

--
-- Name: academic_years_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.academic_years_id_seq OWNED BY public.academic_years.id;


--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_logs (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    user_id bigint,
    action character varying(255) NOT NULL,
    entity_type character varying(255) NOT NULL,
    entity_id bigint,
    old_values json,
    new_values json,
    ip_address character varying(45),
    user_agent text,
    performed_at timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.activity_logs OWNER TO postgres;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO postgres;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: attendances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendances (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    student_id bigint NOT NULL,
    class_id bigint NOT NULL,
    date date NOT NULL,
    status character varying(255) NOT NULL,
    remarks text,
    recorded_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.attendances OWNER TO postgres;

--
-- Name: attendances_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attendances_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attendances_id_seq OWNER TO postgres;

--
-- Name: attendances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attendances_id_seq OWNED BY public.attendances.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO postgres;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO postgres;

--
-- Name: class_subject; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class_subject (
    school_class_id bigint NOT NULL,
    subject_id bigint NOT NULL
);


ALTER TABLE public.class_subject OWNER TO postgres;

--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: form_fields; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.form_fields (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    form_template_id bigint NOT NULL,
    label character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    placeholder character varying(255),
    options json,
    validation_rules json,
    "order" integer DEFAULT 0 NOT NULL,
    is_required boolean DEFAULT true NOT NULL,
    section character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.form_fields OWNER TO postgres;

--
-- Name: form_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.form_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.form_fields_id_seq OWNER TO postgres;

--
-- Name: form_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.form_fields_id_seq OWNED BY public.form_fields.id;


--
-- Name: form_submissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.form_submissions (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    form_template_id bigint NOT NULL,
    data json NOT NULL,
    documents json,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    reviewed_by bigint,
    reviewed_at timestamp(0) without time zone,
    rejection_reason text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.form_submissions OWNER TO postgres;

--
-- Name: form_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.form_submissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.form_submissions_id_seq OWNER TO postgres;

--
-- Name: form_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.form_submissions_id_seq OWNED BY public.form_submissions.id;


--
-- Name: form_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.form_templates (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    academic_year_id bigint,
    is_active boolean DEFAULT true NOT NULL,
    requires_payment boolean DEFAULT false NOT NULL,
    registration_fee numeric(12,2),
    starts_at timestamp(0) without time zone,
    ends_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.form_templates OWNER TO postgres;

--
-- Name: form_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.form_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.form_templates_id_seq OWNER TO postgres;

--
-- Name: form_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.form_templates_id_seq OWNED BY public.form_templates.id;


--
-- Name: grades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grades (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    student_id bigint NOT NULL,
    subject_id bigint NOT NULL,
    class_id bigint NOT NULL,
    academic_year_id bigint,
    term smallint DEFAULT '1'::smallint NOT NULL,
    score numeric(5,2) NOT NULL,
    max_score numeric(5,2) DEFAULT '20'::numeric NOT NULL,
    grade_letter character varying(2),
    comment text,
    recorded_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.grades OWNER TO postgres;

--
-- Name: grades_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grades_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.grades_id_seq OWNER TO postgres;

--
-- Name: grades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grades_id_seq OWNED BY public.grades.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO postgres;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO postgres;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO postgres;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_permissions OWNER TO postgres;

--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_roles OWNER TO postgres;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    student_id bigint NOT NULL,
    academic_year_id bigint,
    amount numeric(12,2) NOT NULL,
    amount_paid numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    due_date date,
    paid_at timestamp(0) without time zone,
    payment_method character varying(255),
    reference_number character varying(255),
    receipt_url character varying(255),
    type character varying(255) DEFAULT 'tuition'::character varying NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    notes text,
    recorded_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permissions_id_seq OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.role_has_permissions OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: school_classes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.school_classes (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    level character varying(255) NOT NULL,
    section character varying(255),
    capacity integer DEFAULT 40 NOT NULL,
    academic_year_id bigint,
    class_teacher_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.school_classes OWNER TO postgres;

--
-- Name: school_classes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.school_classes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.school_classes_id_seq OWNER TO postgres;

--
-- Name: school_classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.school_classes_id_seq OWNED BY public.school_classes.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    user_id bigint NOT NULL,
    matricule character varying(255),
    date_of_birth date,
    gender character varying(255),
    address text,
    guardian_name character varying(255),
    guardian_phone character varying(255),
    guardian_email character varying(255),
    guardian_relationship character varying(255),
    blood_group character varying(255),
    medical_notes text,
    enrollment_date date,
    class_id bigint,
    academic_year_id bigint,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    photo_url character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.students_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.students_id_seq OWNER TO postgres;

--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: subjects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subjects (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255),
    description text,
    coefficient numeric(3,1) DEFAULT '1'::numeric NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.subjects OWNER TO postgres;

--
-- Name: subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subjects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subjects_id_seq OWNER TO postgres;

--
-- Name: subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subjects_id_seq OWNED BY public.subjects.id;


--
-- Name: teacher_class; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teacher_class (
    teacher_id bigint NOT NULL,
    class_id bigint NOT NULL
);


ALTER TABLE public.teacher_class OWNER TO postgres;

--
-- Name: teacher_subject; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teacher_subject (
    teacher_id bigint NOT NULL,
    subject_id bigint NOT NULL
);


ALTER TABLE public.teacher_subject OWNER TO postgres;

--
-- Name: teachers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teachers (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    user_id bigint NOT NULL,
    employee_id character varying(255),
    specialization character varying(255),
    qualification character varying(255),
    hire_date date,
    contract_type character varying(255) DEFAULT 'full-time'::character varying NOT NULL,
    salary numeric(12,2),
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    bio text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.teachers OWNER TO postgres;

--
-- Name: teachers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.teachers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teachers_id_seq OWNER TO postgres;

--
-- Name: teachers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.teachers_id_seq OWNED BY public.teachers.id;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    domain character varying(255),
    email character varying(255),
    phone character varying(255),
    address text,
    logo_url character varying(255),
    favicon_url character varying(255),
    hero_image_url character varying(255),
    primary_color character varying(7) DEFAULT '#1E40AF'::character varying NOT NULL,
    secondary_color character varying(7) DEFAULT '#F59E0B'::character varying NOT NULL,
    accent_color character varying(7) DEFAULT '#10B981'::character varying NOT NULL,
    font_family character varying(255) DEFAULT 'Inter'::character varying NOT NULL,
    tagline character varying(255),
    description text,
    currency character varying(3) DEFAULT 'XOF'::character varying NOT NULL,
    timezone character varying(255) DEFAULT 'Africa/Douala'::character varying NOT NULL,
    locale character varying(5) DEFAULT 'fr'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    settings json,
    subscription_plan character varying(255) DEFAULT 'free'::character varying NOT NULL,
    subscription_expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tenants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tenants_id_seq OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tenants_id_seq OWNED BY public.tenants.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(255),
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    avatar_url character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp(0) without time zone,
    locale character varying(5) DEFAULT 'fr'::character varying NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: academic_years id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_years ALTER COLUMN id SET DEFAULT nextval('public.academic_years_id_seq'::regclass);


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: attendances id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances ALTER COLUMN id SET DEFAULT nextval('public.attendances_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: form_fields id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_fields ALTER COLUMN id SET DEFAULT nextval('public.form_fields_id_seq'::regclass);


--
-- Name: form_submissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_submissions ALTER COLUMN id SET DEFAULT nextval('public.form_submissions_id_seq'::regclass);


--
-- Name: form_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_templates ALTER COLUMN id SET DEFAULT nextval('public.form_templates_id_seq'::regclass);


--
-- Name: grades id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades ALTER COLUMN id SET DEFAULT nextval('public.grades_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: school_classes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_classes ALTER COLUMN id SET DEFAULT nextval('public.school_classes_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: subjects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects ALTER COLUMN id SET DEFAULT nextval('public.subjects_id_seq'::regclass);


--
-- Name: teachers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachers ALTER COLUMN id SET DEFAULT nextval('public.teachers_id_seq'::regclass);


--
-- Name: tenants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants ALTER COLUMN id SET DEFAULT nextval('public.tenants_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: academic_years; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.academic_years (id, tenant_id, name, starts_at, ends_at, is_current, created_at, updated_at) FROM stdin;
1	1	2025-2026	2025-09-01	2026-07-15	t	2026-03-12 14:58:00	2026-03-12 14:58:00
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_logs (id, tenant_id, user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent, performed_at) FROM stdin;
1	1	2	login	App\\Models\\User	2	\N	\N	127.0.0.1	Seeder Agent	2026-03-12 12:58:10
\.


--
-- Data for Name: attendances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendances (id, tenant_id, student_id, class_id, date, status, remarks, recorded_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: class_subject; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class_subject (school_class_id, subject_id) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: form_fields; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.form_fields (id, tenant_id, form_template_id, label, name, type, placeholder, options, validation_rules, "order", is_required, section, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: form_submissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.form_submissions (id, tenant_id, form_template_id, data, documents, status, reviewed_by, reviewed_at, rejection_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: form_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.form_templates (id, tenant_id, name, description, academic_year_id, is_active, requires_payment, registration_fee, starts_at, ends_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grades (id, tenant_id, student_id, subject_id, class_id, academic_year_id, term, score, max_score, grade_letter, comment, recorded_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2025_01_01_000001_create_all_tables	1
2	2026_03_12_144843_create_permission_tables	1
\.


--
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.


--
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
1	App\\Models\\User	1
2	App\\Models\\User	2
5	App\\Models\\User	3
5	App\\Models\\User	4
5	App\\Models\\User	5
5	App\\Models\\User	6
5	App\\Models\\User	7
5	App\\Models\\User	8
5	App\\Models\\User	9
5	App\\Models\\User	10
5	App\\Models\\User	11
5	App\\Models\\User	12
5	App\\Models\\User	13
5	App\\Models\\User	14
5	App\\Models\\User	15
5	App\\Models\\User	16
5	App\\Models\\User	17
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, tenant_id, student_id, academic_year_id, amount, amount_paid, due_date, paid_at, payment_method, reference_number, receipt_url, type, status, notes, recorded_by, created_at, updated_at) FROM stdin;
1	1	9	1	163008.00	0.00	2026-03-10	\N	cash	\N	\N	tuition	paid	Frais de scolarité Trimestre 3	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
2	1	10	1	123092.00	0.00	2026-03-17	\N	cash	\N	\N	tuition	paid	Frais de scolarité Trimestre 1	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
3	1	5	1	140227.00	0.00	2026-03-20	\N	cash	\N	\N	tuition	pending	Frais de scolarité Trimestre 2	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
4	1	14	1	182001.00	0.00	2026-03-18	\N	cash	\N	\N	tuition	overdue	Frais de scolarité Trimestre 2	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
5	1	3	1	190044.00	0.00	2026-03-10	\N	cash	\N	\N	tuition	paid	Frais de scolarité Trimestre 2	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
6	1	7	1	82409.00	0.00	2026-03-22	\N	cash	\N	\N	tuition	pending	Frais de scolarité Trimestre 3	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
7	1	2	1	149490.00	0.00	2026-03-15	\N	cash	\N	\N	tuition	paid	Frais de scolarité Trimestre 2	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
8	1	5	1	70159.00	0.00	2026-03-20	\N	cash	\N	\N	tuition	overdue	Frais de scolarité Trimestre 1	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
9	1	2	1	100324.00	0.00	2026-03-14	\N	cash	\N	\N	tuition	pending	Frais de scolarité Trimestre 2	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
10	1	2	1	96759.00	0.00	2026-03-13	\N	cash	\N	\N	tuition	paid	Frais de scolarité Trimestre 3	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
1	view-students	web	2026-03-12 14:57:56	2026-03-12 14:57:56
2	manage-students	web	2026-03-12 14:57:56	2026-03-12 14:57:56
3	view-teachers	web	2026-03-12 14:57:56	2026-03-12 14:57:56
4	manage-teachers	web	2026-03-12 14:57:57	2026-03-12 14:57:57
5	view-grades	web	2026-03-12 14:57:57	2026-03-12 14:57:57
6	edit-grades	web	2026-03-12 14:57:57	2026-03-12 14:57:57
7	view-financials	web	2026-03-12 14:57:57	2026-03-12 14:57:57
8	manage-payments	web	2026-03-12 14:57:57	2026-03-12 14:57:57
9	view-attendance	web	2026-03-12 14:57:57	2026-03-12 14:57:57
10	manage-attendance	web	2026-03-12 14:57:57	2026-03-12 14:57:57
11	manage-users	web	2026-03-12 14:57:57	2026-03-12 14:57:57
12	manage-school	web	2026-03-12 14:57:57	2026-03-12 14:57:57
13	view-reports	web	2026-03-12 14:57:57	2026-03-12 14:57:57
14	generate-reports	web	2026-03-12 14:57:57	2026-03-12 14:57:57
15	manage-forms	web	2026-03-12 14:57:57	2026-03-12 14:57:57
16	view-activity-logs	web	2026-03-12 14:57:57	2026-03-12 14:57:57
17	manage-vitrine	web	2026-03-12 14:57:57	2026-03-12 14:57:57
\.


--
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
1	1
2	1
3	1
4	1
5	1
6	1
7	1
8	1
9	1
10	1
11	1
12	1
13	1
14	1
15	1
16	1
17	1
1	2
2	2
3	2
4	2
5	2
6	2
7	2
8	2
9	2
10	2
11	2
12	2
13	2
14	2
15	2
16	2
17	2
1	3
5	3
6	3
9	3
10	3
1	4
5	4
7	4
9	4
5	5
9	5
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
1	founder	web	2026-03-12 14:57:57	2026-03-12 14:57:57
2	admin-school	web	2026-03-12 14:57:57	2026-03-12 14:57:57
3	teacher	web	2026-03-12 14:57:58	2026-03-12 14:57:58
4	parent	web	2026-03-12 14:57:58	2026-03-12 14:57:58
5	student	web	2026-03-12 14:57:58	2026-03-12 14:57:58
\.


--
-- Data for Name: school_classes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.school_classes (id, tenant_id, name, level, section, capacity, academic_year_id, class_teacher_id, created_at, updated_at) FROM stdin;
1	1	6ème A	secondary	A	45	1	\N	2026-03-12 14:58:01	2026-03-12 14:58:01
2	1	Terminale S	high_school	S	35	1	\N	2026-03-12 14:58:01	2026-03-12 14:58:01
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (id, tenant_id, user_id, matricule, date_of_birth, gender, address, guardian_name, guardian_phone, guardian_email, guardian_relationship, blood_group, medical_notes, enrollment_date, class_id, academic_year_id, status, photo_url, created_at, updated_at) FROM stdin;
1	1	3	STU-2026-001	2010-01-01	M	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:01	2026-03-12 14:58:01
2	1	4	STU-2026-002	2010-01-01	F	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:02	2026-03-12 14:58:02
3	1	5	STU-2026-003	2010-01-01	M	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:02	2026-03-12 14:58:02
4	1	6	STU-2026-004	2010-01-01	F	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:03	2026-03-12 14:58:03
5	1	7	STU-2026-005	2010-01-01	M	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:04	2026-03-12 14:58:04
6	1	8	STU-2026-006	2010-01-01	F	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:05	2026-03-12 14:58:05
7	1	9	STU-2026-007	2010-01-01	M	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:05	2026-03-12 14:58:05
8	1	10	STU-2026-008	2010-01-01	F	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:06	2026-03-12 14:58:06
9	1	11	STU-2026-009	2010-01-01	M	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:06	2026-03-12 14:58:06
10	1	12	STU-2026-010	2010-01-01	F	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:07	2026-03-12 14:58:07
11	1	13	STU-2026-011	2010-01-01	M	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:07	2026-03-12 14:58:07
12	1	14	STU-2026-012	2010-01-01	F	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:08	2026-03-12 14:58:08
13	1	15	STU-2026-013	2010-01-01	M	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:09	2026-03-12 14:58:09
14	1	16	STU-2026-014	2010-01-01	F	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:09	2026-03-12 14:58:09
15	1	17	STU-2026-015	2010-01-01	M	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	active	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subjects (id, tenant_id, name, code, description, coefficient, is_active, created_at, updated_at) FROM stdin;
1	1	Mathématiques	MAT1	\N	2.1	t	2026-03-12 14:58:00	2026-03-12 14:58:00
2	1	Français	FRA2	\N	3.2	t	2026-03-12 14:58:01	2026-03-12 14:58:01
3	1	Anglais	ANG3	\N	2.1	t	2026-03-12 14:58:01	2026-03-12 14:58:01
4	1	Physique-Chimie	PHY4	\N	2.5	t	2026-03-12 14:58:01	2026-03-12 14:58:01
5	1	SVT	SVT5	\N	1.4	t	2026-03-12 14:58:01	2026-03-12 14:58:01
6	1	Histoire-Géo	HIS6	\N	3.1	t	2026-03-12 14:58:01	2026-03-12 14:58:01
7	1	Informatique	INF7	\N	1.5	t	2026-03-12 14:58:01	2026-03-12 14:58:01
\.


--
-- Data for Name: teacher_class; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teacher_class (teacher_id, class_id) FROM stdin;
\.


--
-- Data for Name: teacher_subject; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teacher_subject (teacher_id, subject_id) FROM stdin;
\.


--
-- Data for Name: teachers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teachers (id, tenant_id, user_id, employee_id, specialization, qualification, hire_date, contract_type, salary, status, bio, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name, slug, domain, email, phone, address, logo_url, favicon_url, hero_image_url, primary_color, secondary_color, accent_color, font_family, tagline, description, currency, timezone, locale, is_active, settings, subscription_plan, subscription_expires_at, created_at, updated_at) FROM stdin;
1	École Horizon	horizon	horizon.o-229.com	admin@horizon.o-229.com	\N	\N	\N	\N	\N	#1E40AF	#F59E0B	#10B981	Inter	Former les leaders de demain	\N	XOF	Africa/Douala	fr	t	\N	free	\N	2026-03-12 14:57:58	2026-03-12 14:57:58
2	Lycée Étoile	etoile	etoile.o-229.com	admin@etoile.o-229.com	\N	\N	\N	\N	\N	#7C3AED	#EF4444	#06B6D4	Inter	L'excellence par la discipline	\N	XOF	Africa/Douala	fr	t	\N	free	\N	2026-03-12 14:57:58	2026-03-12 14:57:58
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, tenant_id, first_name, last_name, email, phone, email_verified_at, password, avatar_url, is_active, last_login_at, locale, remember_token, created_at, updated_at) FROM stdin;
1	1	Michel	Fondateur	founder@o-229.com	\N	\N	$2y$12$Bf6NdL3ZGPjyXGWryTVrgOZIDMeRJRLrVdoX6C8OEHE/YoDr5s6P2	\N	t	\N	fr	\N	2026-03-12 14:57:59	2026-03-12 14:57:59
2	1	Jean	Admin	admin@horizon.o-229.com	\N	\N	$2y$12$th9MbwQf0AER5SdIrN2EqOk7eIuvyeIWXvotYwg.cUhEphOdcTdwy	\N	t	\N	fr	\N	2026-03-12 14:58:00	2026-03-12 14:58:00
3	1	Élève 1	Demo	eleve1@horizon.o-229.com	\N	\N	$2y$12$ZsS1l4cL3Sgt9WAdF6dVnu8UJC6MiFzolT2b3MvgLQHRhuyp9Kb.y	\N	t	\N	fr	\N	2026-03-12 14:58:01	2026-03-12 14:58:01
4	1	Élève 2	Demo	eleve2@horizon.o-229.com	\N	\N	$2y$12$UHAvrNt99graIKHB17Lg.OeOcjT986FQp95L6jP7vTF.0yaoMoTa.	\N	t	\N	fr	\N	2026-03-12 14:58:02	2026-03-12 14:58:02
5	1	Élève 3	Demo	eleve3@horizon.o-229.com	\N	\N	$2y$12$y8z1S0S6ea7o2Z.smH4wKeomhVz3Oezz19GceuvkarwnPxGSJMhHS	\N	t	\N	fr	\N	2026-03-12 14:58:02	2026-03-12 14:58:02
6	1	Élève 4	Demo	eleve4@horizon.o-229.com	\N	\N	$2y$12$8s4Q..RTdtEuBMLfvtdPNe1M2RCQ0sHgPusUKEaLpL.rykKJIm3ua	\N	t	\N	fr	\N	2026-03-12 14:58:03	2026-03-12 14:58:03
7	1	Élève 5	Demo	eleve5@horizon.o-229.com	\N	\N	$2y$12$bzdTWY0WYUA3mKFXibUXLeM2m5vx5O1egMK7LtmRYLFICryEf2PjW	\N	t	\N	fr	\N	2026-03-12 14:58:04	2026-03-12 14:58:04
8	1	Élève 6	Demo	eleve6@horizon.o-229.com	\N	\N	$2y$12$yGG0B1ylmcs2HCJshVT5E.BlIq0WrsfPn7l7piuf8YI9ak9ZLSW4a	\N	t	\N	fr	\N	2026-03-12 14:58:05	2026-03-12 14:58:05
9	1	Élève 7	Demo	eleve7@horizon.o-229.com	\N	\N	$2y$12$MR0zAfmlHWMtW0uFa5teSOukehxnhje7EX1umR3bOiJsfYms5oesm	\N	t	\N	fr	\N	2026-03-12 14:58:05	2026-03-12 14:58:05
10	1	Élève 8	Demo	eleve8@horizon.o-229.com	\N	\N	$2y$12$JkVOVb8FIRcI1u5XZFU5XuF31tG6HeGuIkt1RVCD4ukHn7USAAxM.	\N	t	\N	fr	\N	2026-03-12 14:58:06	2026-03-12 14:58:06
11	1	Élève 9	Demo	eleve9@horizon.o-229.com	\N	\N	$2y$12$H9dQydhH1UlFoqRQDl59XeIunPRC6DLEwwdkOrZGA.muW7Ir.mUwG	\N	t	\N	fr	\N	2026-03-12 14:58:06	2026-03-12 14:58:06
12	1	Élève 10	Demo	eleve10@horizon.o-229.com	\N	\N	$2y$12$fceJqvKRYxdnE5iGW4MVTu9ZQJBGzvdLOYAL1w36uFrDtBnnoiPei	\N	t	\N	fr	\N	2026-03-12 14:58:07	2026-03-12 14:58:07
13	1	Élève 11	Demo	eleve11@horizon.o-229.com	\N	\N	$2y$12$Xvgd5QGstdKSq9XkZLVz8.HMUa/RQY/L6S5W0RjliIh75guK9Osy.	\N	t	\N	fr	\N	2026-03-12 14:58:07	2026-03-12 14:58:07
14	1	Élève 12	Demo	eleve12@horizon.o-229.com	\N	\N	$2y$12$j2Z76wN746Gq.ERoGW5CeO95RGBT./ac0VpqRCROxsGoIqJagkAM6	\N	t	\N	fr	\N	2026-03-12 14:58:08	2026-03-12 14:58:08
15	1	Élève 13	Demo	eleve13@horizon.o-229.com	\N	\N	$2y$12$oGoz29mOV84xtIhrG5AoPeatOati9mHQ9ye1sHmEn0QC6p/kZ/Tyu	\N	t	\N	fr	\N	2026-03-12 14:58:09	2026-03-12 14:58:09
16	1	Élève 14	Demo	eleve14@horizon.o-229.com	\N	\N	$2y$12$RbHFkmxiXSAchSqSwQQOje4DYXUHa0fdRXd1EC78nyR6Iwk69bKyW	\N	t	\N	fr	\N	2026-03-12 14:58:09	2026-03-12 14:58:09
17	1	Élève 15	Demo	eleve15@horizon.o-229.com	\N	\N	$2y$12$MVIRv9az7UJpblP7T6LJ/.wrbCf93KdgphQz7IewNzlSMhQyECzgC	\N	t	\N	fr	\N	2026-03-12 14:58:10	2026-03-12 14:58:10
\.


--
-- Name: academic_years_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.academic_years_id_seq', 1, true);


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 1, true);


--
-- Name: attendances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attendances_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: form_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.form_fields_id_seq', 1, false);


--
-- Name: form_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.form_submissions_id_seq', 1, false);


--
-- Name: form_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.form_templates_id_seq', 1, false);


--
-- Name: grades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grades_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 2, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_id_seq', 10, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 17, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 5, true);


--
-- Name: school_classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.school_classes_id_seq', 2, true);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.students_id_seq', 15, true);


--
-- Name: subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subjects_id_seq', 7, true);


--
-- Name: teachers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teachers_id_seq', 1, false);


--
-- Name: tenants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tenants_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 17, true);


--
-- Name: academic_years academic_years_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_pkey PRIMARY KEY (id);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: attendances attendances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_pkey PRIMARY KEY (id);


--
-- Name: attendances attendances_tenant_id_student_id_date_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_tenant_id_student_id_date_unique UNIQUE (tenant_id, student_id, date);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: class_subject class_subject_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_subject
    ADD CONSTRAINT class_subject_pkey PRIMARY KEY (school_class_id, subject_id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: form_fields form_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_fields
    ADD CONSTRAINT form_fields_pkey PRIMARY KEY (id);


--
-- Name: form_submissions form_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_pkey PRIMARY KEY (id);


--
-- Name: form_templates form_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_templates
    ADD CONSTRAINT form_templates_pkey PRIMARY KEY (id);


--
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: roles roles_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: school_classes school_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_classes
    ADD CONSTRAINT school_classes_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: students students_tenant_id_matricule_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_tenant_id_matricule_unique UNIQUE (tenant_id, matricule);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_tenant_id_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_tenant_id_code_unique UNIQUE (tenant_id, code);


--
-- Name: teacher_class teacher_class_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacher_class
    ADD CONSTRAINT teacher_class_pkey PRIMARY KEY (teacher_id, class_id);


--
-- Name: teacher_subject teacher_subject_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacher_subject
    ADD CONSTRAINT teacher_subject_pkey PRIMARY KEY (teacher_id, subject_id);


--
-- Name: teachers teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_pkey PRIMARY KEY (id);


--
-- Name: teachers teachers_tenant_id_employee_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_tenant_id_employee_id_unique UNIQUE (tenant_id, employee_id);


--
-- Name: tenants tenants_domain_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_domain_unique UNIQUE (domain);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_unique UNIQUE (slug);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_tenant_id_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_email_unique UNIQUE (tenant_id, email);


--
-- Name: academic_years_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX academic_years_tenant_id_index ON public.academic_years USING btree (tenant_id);


--
-- Name: activity_logs_tenant_id_action_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activity_logs_tenant_id_action_index ON public.activity_logs USING btree (tenant_id, action);


--
-- Name: activity_logs_tenant_id_entity_type_entity_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activity_logs_tenant_id_entity_type_entity_id_index ON public.activity_logs USING btree (tenant_id, entity_type, entity_id);


--
-- Name: activity_logs_tenant_id_performed_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activity_logs_tenant_id_performed_at_index ON public.activity_logs USING btree (tenant_id, performed_at);


--
-- Name: activity_logs_tenant_id_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX activity_logs_tenant_id_user_id_index ON public.activity_logs USING btree (tenant_id, user_id);


--
-- Name: attendances_tenant_id_date_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendances_tenant_id_date_index ON public.attendances USING btree (tenant_id, date);


--
-- Name: attendances_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attendances_tenant_id_index ON public.attendances USING btree (tenant_id);


--
-- Name: form_fields_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX form_fields_tenant_id_index ON public.form_fields USING btree (tenant_id);


--
-- Name: form_submissions_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX form_submissions_tenant_id_index ON public.form_submissions USING btree (tenant_id);


--
-- Name: form_submissions_tenant_id_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX form_submissions_tenant_id_status_index ON public.form_submissions USING btree (tenant_id, status);


--
-- Name: form_templates_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX form_templates_tenant_id_index ON public.form_templates USING btree (tenant_id);


--
-- Name: grades_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX grades_tenant_id_index ON public.grades USING btree (tenant_id);


--
-- Name: grades_tenant_id_student_id_term_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX grades_tenant_id_student_id_term_index ON public.grades USING btree (tenant_id, student_id, term);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: payments_tenant_id_due_date_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payments_tenant_id_due_date_index ON public.payments USING btree (tenant_id, due_date);


--
-- Name: payments_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payments_tenant_id_index ON public.payments USING btree (tenant_id);


--
-- Name: payments_tenant_id_status_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payments_tenant_id_status_index ON public.payments USING btree (tenant_id, status);


--
-- Name: school_classes_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX school_classes_tenant_id_index ON public.school_classes USING btree (tenant_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: students_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX students_tenant_id_index ON public.students USING btree (tenant_id);


--
-- Name: subjects_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subjects_tenant_id_index ON public.subjects USING btree (tenant_id);


--
-- Name: teachers_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX teachers_tenant_id_index ON public.teachers USING btree (tenant_id);


--
-- Name: users_tenant_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_tenant_id_index ON public.users USING btree (tenant_id);


--
-- Name: academic_years academic_years_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: attendances attendances_class_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_class_id_foreign FOREIGN KEY (class_id) REFERENCES public.school_classes(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_recorded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_recorded_by_foreign FOREIGN KEY (recorded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: attendances attendances_student_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_student_id_foreign FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: class_subject class_subject_school_class_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_subject
    ADD CONSTRAINT class_subject_school_class_id_foreign FOREIGN KEY (school_class_id) REFERENCES public.school_classes(id) ON DELETE CASCADE;


--
-- Name: class_subject class_subject_subject_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_subject
    ADD CONSTRAINT class_subject_subject_id_foreign FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: form_fields form_fields_form_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_fields
    ADD CONSTRAINT form_fields_form_template_id_foreign FOREIGN KEY (form_template_id) REFERENCES public.form_templates(id) ON DELETE CASCADE;


--
-- Name: form_fields form_fields_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_fields
    ADD CONSTRAINT form_fields_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: form_submissions form_submissions_form_template_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_form_template_id_foreign FOREIGN KEY (form_template_id) REFERENCES public.form_templates(id) ON DELETE CASCADE;


--
-- Name: form_submissions form_submissions_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: form_submissions form_submissions_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_submissions
    ADD CONSTRAINT form_submissions_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: form_templates form_templates_academic_year_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_templates
    ADD CONSTRAINT form_templates_academic_year_id_foreign FOREIGN KEY (academic_year_id) REFERENCES public.academic_years(id) ON DELETE SET NULL;


--
-- Name: form_templates form_templates_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_templates
    ADD CONSTRAINT form_templates_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: grades grades_academic_year_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_academic_year_id_foreign FOREIGN KEY (academic_year_id) REFERENCES public.academic_years(id) ON DELETE SET NULL;


--
-- Name: grades grades_class_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_class_id_foreign FOREIGN KEY (class_id) REFERENCES public.school_classes(id) ON DELETE CASCADE;


--
-- Name: grades grades_recorded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_recorded_by_foreign FOREIGN KEY (recorded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: grades grades_student_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_student_id_foreign FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: grades grades_subject_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_subject_id_foreign FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: grades grades_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: payments payments_academic_year_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_academic_year_id_foreign FOREIGN KEY (academic_year_id) REFERENCES public.academic_years(id) ON DELETE SET NULL;


--
-- Name: payments payments_recorded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_recorded_by_foreign FOREIGN KEY (recorded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payments payments_student_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_student_id_foreign FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: payments payments_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: school_classes school_classes_academic_year_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_classes
    ADD CONSTRAINT school_classes_academic_year_id_foreign FOREIGN KEY (academic_year_id) REFERENCES public.academic_years(id) ON DELETE SET NULL;


--
-- Name: school_classes school_classes_class_teacher_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_classes
    ADD CONSTRAINT school_classes_class_teacher_id_foreign FOREIGN KEY (class_teacher_id) REFERENCES public.teachers(id) ON DELETE SET NULL;


--
-- Name: school_classes school_classes_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_classes
    ADD CONSTRAINT school_classes_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: students students_academic_year_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_academic_year_id_foreign FOREIGN KEY (academic_year_id) REFERENCES public.academic_years(id) ON DELETE SET NULL;


--
-- Name: students students_class_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_class_id_foreign FOREIGN KEY (class_id) REFERENCES public.school_classes(id) ON DELETE SET NULL;


--
-- Name: students students_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: students students_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subjects subjects_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: teacher_class teacher_class_class_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacher_class
    ADD CONSTRAINT teacher_class_class_id_foreign FOREIGN KEY (class_id) REFERENCES public.school_classes(id) ON DELETE CASCADE;


--
-- Name: teacher_class teacher_class_teacher_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacher_class
    ADD CONSTRAINT teacher_class_teacher_id_foreign FOREIGN KEY (teacher_id) REFERENCES public.teachers(id) ON DELETE CASCADE;


--
-- Name: teacher_subject teacher_subject_subject_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacher_subject
    ADD CONSTRAINT teacher_subject_subject_id_foreign FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE CASCADE;


--
-- Name: teacher_subject teacher_subject_teacher_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teacher_subject
    ADD CONSTRAINT teacher_subject_teacher_id_foreign FOREIGN KEY (teacher_id) REFERENCES public.teachers(id) ON DELETE CASCADE;


--
-- Name: teachers teachers_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: teachers teachers_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict gZCmezhhFJ4sXScheSoMLETqnSDqkjwlIsd17P0TBvNQ22vaetqAXwLmdP0u8TO

